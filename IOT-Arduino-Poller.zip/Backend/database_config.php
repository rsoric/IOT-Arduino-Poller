<?php

    final class DBConfig
    {
        const serverName = "eu-cdbr-west-02.cleardb.net";
        const dbUsername = "b8100c5581c24b";
        const dbPassword = "2ab80845";
        const dbName = "heroku_526e4c652212ab8";
    }