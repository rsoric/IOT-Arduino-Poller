<footer class="mt-auto">
<p>&copy; Copyright 2022, Štrafasti Ris Smart Devices & Intelligent Systems co.</p>
</footer>
</div>

</body>

</html>